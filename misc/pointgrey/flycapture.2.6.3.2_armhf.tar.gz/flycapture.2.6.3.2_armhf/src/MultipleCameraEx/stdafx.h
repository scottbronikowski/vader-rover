// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#if defined(WIN32) || defined(WIN64)

#pragma once

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows XP or later.                   
#define _WIN32_WINNT 0x0501	// Change this to the appropriate value to target other versions of Windows.
#endif			

#define _CRT_SECURE_NO_WARNINGS				

#include <stdio.h>
#include <tchar.h>

#elif defined(MACOSX)

#else

#include <stdio.h>

#endif
